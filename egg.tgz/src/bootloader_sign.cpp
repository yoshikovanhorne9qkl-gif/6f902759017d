// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Sign and append header"); }
int main(){
  announce();
  return lionss_run_workload("bootloader_sign");
}
