// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Rank with freshness decay"); }
int main(){
  announce();
  return lionss_run_workload("feedRank");
}
