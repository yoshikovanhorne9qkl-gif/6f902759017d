// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Annual yield estimate"); }
int main(){
  announce();
  return lionss_run_workload("roofsolar");
}
