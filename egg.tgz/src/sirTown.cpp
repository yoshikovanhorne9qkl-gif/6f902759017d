// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Simulate 180 days\n", stdout);
  return lionss_run_workload("sirTown");
}
