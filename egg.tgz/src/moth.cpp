// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Emit sitemap index"); }
int main(){
  announce();
  return lionss_run_workload("moth");
}
