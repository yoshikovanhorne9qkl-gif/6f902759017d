// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(int argc, char** argv){
  (void)argc; (void)argv;
  std::printf("%s\n", "Rewrite 2k host addresses");
  std::fflush(stdout);
  return lionss_run_workload("ipv6renumber");
}
