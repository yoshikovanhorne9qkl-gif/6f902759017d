// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Validate and route admissions\n", stdout);
  return lionss_run_workload("FhirIntake");
}
