// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Plan with no refresh\n", stdout);
  return lionss_run_workload("tfPlanDry");
}
