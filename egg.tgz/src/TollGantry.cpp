// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Match reads to trips"); }
int main(){
  announce();
  return lionss_run_workload("TollGantry");
}
