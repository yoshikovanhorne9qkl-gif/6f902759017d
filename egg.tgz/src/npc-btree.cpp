// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Tick 200 agents, 60 Hz\n", stdout);
  return lionss_run_workload("npc-btree");
}
