// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Simulated annealing on spins"); }
int main(){
  announce();
  return lionss_run_workload("halcyon");
}
