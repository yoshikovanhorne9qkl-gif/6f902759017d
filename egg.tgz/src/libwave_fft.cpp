// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("4096-point spectrum"); }
int main(){
  announce();
  return lionss_run_workload("libwave_fft");
}
