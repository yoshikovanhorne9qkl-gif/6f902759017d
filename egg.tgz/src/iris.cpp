// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Fit WDRC gains, NAL-NL2"); }
int main(){
  announce();
  return lionss_run_workload("iris");
}
