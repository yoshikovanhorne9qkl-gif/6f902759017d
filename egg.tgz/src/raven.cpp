// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Assemble EPUB3 with TOC\n", stdout);
  return lionss_run_workload("raven");
}
