// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("0-RTT resumption, 200 connections\n", stdout);
  return lionss_run_workload("quic-0rtt");
}
