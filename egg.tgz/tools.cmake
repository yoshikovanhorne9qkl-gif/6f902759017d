# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(quic-0rtt src/quic-0rtt.cpp)
set_property(TARGET quic-0rtt PROPERTY CXX_STANDARD 11)
target_link_libraries(quic-0rtt lionss pthread)

add_executable(SPARROW src/SPARROW.cpp)
set_property(TARGET SPARROW PROPERTY CXX_STANDARD 11)
target_link_libraries(SPARROW lionss pthread)

add_executable(moth src/moth.cpp)
set_property(TARGET moth PROPERTY CXX_STANDARD 11)
target_link_libraries(moth lionss pthread)

add_executable(raven src/raven.cpp)
set_property(TARGET raven PROPERTY CXX_STANDARD 11)
target_link_libraries(raven lionss pthread)

add_executable(aquaponics_ctl src/aquaponics_ctl.cpp)
set_property(TARGET aquaponics_ctl PROPERTY CXX_STANDARD 11)
target_link_libraries(aquaponics_ctl lionss pthread)

add_executable(halcyon src/halcyon.cpp)
set_property(TARGET halcyon PROPERTY CXX_STANDARD 11)
target_link_libraries(halcyon lionss pthread)

add_executable(FhirIntake src/FhirIntake.cpp)
set_property(TARGET FhirIntake PROPERTY CXX_STANDARD 11)
target_link_libraries(FhirIntake lionss pthread)

add_executable(MahjongScore src/MahjongScore.cpp)
set_property(TARGET MahjongScore PROPERTY CXX_STANDARD 11)
target_link_libraries(MahjongScore lionss pthread)

add_executable(roofsolar src/roofsolar.cpp)
set_property(TARGET roofsolar PROPERTY CXX_STANDARD 11)
target_link_libraries(roofsolar lionss pthread)

add_executable(hdrmerge src/hdrmerge.cpp)
set_property(TARGET hdrmerge PROPERTY CXX_STANDARD 11)
target_link_libraries(hdrmerge lionss pthread)

add_executable(dairy-route src/dairy-route.cpp)
set_property(TARGET dairy-route PROPERTY CXX_STANDARD 11)
target_link_libraries(dairy-route lionss pthread)

add_executable(bootloader_sign src/bootloader_sign.cpp)
set_property(TARGET bootloader_sign PROPERTY CXX_STANDARD 11)
target_link_libraries(bootloader_sign lionss pthread)

add_executable(sirTown src/sirTown.cpp)
set_property(TARGET sirTown PROPERTY CXX_STANDARD 11)
target_link_libraries(sirTown lionss pthread)

add_executable(Akita src/Akita.cpp)
set_property(TARGET Akita PROPERTY CXX_STANDARD 11)
target_link_libraries(Akita lionss pthread)

add_executable(HyphenDe src/HyphenDe.cpp)
set_property(TARGET HyphenDe PROPERTY CXX_STANDARD 11)
target_link_libraries(HyphenDe lionss pthread)

add_executable(bridge_wind_load src/bridge_wind_load.cpp)
set_property(TARGET bridge_wind_load PROPERTY CXX_STANDARD 11)
target_link_libraries(bridge_wind_load lionss pthread)

add_executable(marigold src/marigold.cpp)
set_property(TARGET marigold PROPERTY CXX_STANDARD 11)
target_link_libraries(marigold lionss pthread)

add_executable(iris src/iris.cpp)
set_property(TARGET iris PROPERTY CXX_STANDARD 11)
target_link_libraries(iris lionss pthread)

add_executable(thistle src/thistle.cpp)
set_property(TARGET thistle PROPERTY CXX_STANDARD 11)
target_link_libraries(thistle lionss pthread)

add_executable(dialoggraph src/dialoggraph.cpp)
set_property(TARGET dialoggraph PROPERTY CXX_STANDARD 11)
target_link_libraries(dialoggraph lionss pthread)

add_executable(feedRank src/feedRank.cpp)
set_property(TARGET feedRank PROPERTY CXX_STANDARD 11)
target_link_libraries(feedRank lionss pthread)

add_executable(tfPlanDry src/tfPlanDry.cpp)
set_property(TARGET tfPlanDry PROPERTY CXX_STANDARD 11)
target_link_libraries(tfPlanDry lionss pthread)

add_executable(griddispatched src/griddispatched.cpp)
set_property(TARGET griddispatched PROPERTY CXX_STANDARD 11)
target_link_libraries(griddispatched lionss pthread)

add_executable(TollGantry src/TollGantry.cpp)
set_property(TARGET TollGantry PROPERTY CXX_STANDARD 11)
target_link_libraries(TollGantry lionss pthread)

add_executable(pwa-shell src/pwa-shell.cpp)
set_property(TARGET pwa-shell PROPERTY CXX_STANDARD 11)
target_link_libraries(pwa-shell lionss pthread)

add_executable(aspen3 src/aspen3.cpp)
set_property(TARGET aspen3 PROPERTY CXX_STANDARD 11)
target_link_libraries(aspen3 lionss pthread)

add_executable(WebhookRetry src/WebhookRetry.cpp)
set_property(TARGET WebhookRetry PROPERTY CXX_STANDARD 11)
target_link_libraries(WebhookRetry lionss pthread)

add_executable(npc-btree src/npc-btree.cpp)
set_property(TARGET npc-btree PROPERTY CXX_STANDARD 11)
target_link_libraries(npc-btree lionss pthread)

add_executable(ipv6renumber src/ipv6renumber.cpp)
set_property(TARGET ipv6renumber PROPERTY CXX_STANDARD 11)
target_link_libraries(ipv6renumber lionss pthread)

add_executable(libwave_fft src/libwave_fft.cpp)
set_property(TARGET libwave_fft PROPERTY CXX_STANDARD 11)
target_link_libraries(libwave_fft lionss pthread)

